"""Problem types mainly define the properties and criterions depending on
   how inputs should be mapped to outputs.

"""
from .supervised_problem import SupervisedProblem
