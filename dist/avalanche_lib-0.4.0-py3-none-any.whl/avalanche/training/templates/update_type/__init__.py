"""Update types define how the model is updated for every batch of data.
"""

from .sgd_update import SGDUpdate
from .meta_update import MetaUpdate
