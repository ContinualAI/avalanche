################################################################################
# Copyright (c) 2020 ContinualAI Research                                      #
# Copyrights licensed under the MIT License.                                   #
# See the accompanying LICENSE file for terms.                                 #
#                                                                              #
# Date: 19-02-2021                                                             #
# Author: Tyler L. Hayes                                                       #
# E-mail: contact@continualai.org                                              #
# Website: continualai.org                                                     #
################################################################################

name = (
    "Stream-51.zip",
    "http://klab.cis.rit.edu/files/Stream-51.zip",
    "5f34d542b71af7e5ecb2226d1bc7297c",
)


__all__ = ["name"]
