from avalanche.core import SupervisedPlugin
