from .core50 import CORe50Dataset
